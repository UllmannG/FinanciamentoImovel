import java.sql.SQLOutput;
import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        boolean temEmpresa;
        boolean temEmprego = true;
        int valorEntrada;
        int scoreSerasa = 800;

        Scanner scanner = new Scanner(System.in);

        System.out.print("Você possui Empresa propria? (Sim/Não)\n");
        String respostaEmpresa = scanner.next().toLowerCase();
        temEmpresa = respostaEmpresa.equals("sim");

        if (!temEmpresa) {
            System.out.print("Você possui emprego? (Sim/Não)\n");
            String respostaEmprego = scanner.next().toLowerCase();
            temEmprego= respostaEmprego.equals("sim");
            if (!temEmprego) {
                System.out.print("Voce precisa ter emprego ou empresa para poder financiar um imóvel.");
                return;
            }
        }

        System.out.print("Quanto que você possui de entrada?\n: ");
        valorEntrada = scanner.nextInt();
        boolean tem50k = (valorEntrada >= 50000);

        if (!tem50k) {

            System.out.print("Voce não possui valor suficiente para dar entrada!");
            return;
        }

        System.out.print("Informe o seu score no Serasa: \n");
        scoreSerasa = scanner.nextInt();

        scanner.close();

        boolean podeFinanciar = (temEmprego || temEmpresa) && tem50k && (scoreSerasa >= 800);

        if (!podeFinanciar) {

            System.out.print( "Você não pode financiar");

        } else {

            System.out.println("\n Você pode financiar!");
        }
    }
}